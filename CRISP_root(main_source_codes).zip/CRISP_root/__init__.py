#!/usr/bin/python
# CRISP: GCxGC-TOFMS Contour ROI Identification, Simulation & untargeted metabolomics Profiler")
# Mathema et al 2021, Khoomrung S: Siriraj Metabolomics & Phenomics Center (SiMPC), Mahidol University, Bangkok, Thailand
# Software code under review


'''
 ########    #########     ####    ########    ######### 
 ##    ##    ##     ##      ##     ##    ##    ##     ## 
 ##          ##     ##      ##     ##          ##     ##  
 ##          #######        ##      #######    #########  
 ##          ##    ##       ##           ##    ##        
 ##    ##    ##     ##      ##     ##    ##    ##        
 ########    ##      ##    ####    ########    ##       
------------------------------------------------------------------------------------------------------------------------------------------------------------------
__author__      = "Mathema VB, Duangkumpha K, Wanichthanarak K, Jariyasopit N, Dhaka E, Sathirapongsasuti N, Kitiyakara C,Sirivatanauksorn Y, Sakda Khoomrung S*  |
__institute__   = "Metabolomics and Systems Biology,Department of Biochemistry,Faculty of Medicine Siriraj Hospital, Mahidol University, Bangkok 10700, Thailand" |
__license__     = "GNU/GPL"                                                                                                                                       |
__version__     = "0.01"                                                                                                                                          |
__maintainer__  =  "VBM"                                                                                                                                          |
__email__       = "vivek_mathema@hotmail.com"                                                                                                                     |
__status__      = "Briefings in Bioinformatics (accepted, in press)"                                                                                                                                  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Citation information

@article {vbm2021crisp,
   title ={CRISP: A Deep Learning Architecture for GC×GC-TOFMS Contour ROI Identification, Simulation, and Analysis in Imaging Metabolomics},
   author={Mathema VB, Duangkumpha K, Wanichthanarak K, Jariyasopit N, Dhakal E, Sathirapongsasuti N, Kitiyakara C, Sirivatanauksorn Y, Khoomrung S},
   journal={BIB},
   year={2021}
   }
'''