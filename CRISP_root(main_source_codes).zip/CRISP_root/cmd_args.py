#!/usr/bin/python
# GPU Version of CRISP main source code 
# CRISP: GCxGC-TOFMS Contour ROI Identification, Simulation & untargeted metabolomics Profiler")
# Mathema et al 2021, Khoomrung S: Siriraj Metabolomics & Phenomics Center (SiMPC), Mahidol University, Bangkok, Thailand
# Software code under review
# encoding: utf-8
# File: [cmd_args.py] Script to handel Command line arguments for CRISP 

'''
 ########    #########     ####    ########    ######### 
 ##    ##    ##     ##      ##     ##    ##    ##     ## 
 ##          ##     ##      ##     ##          ##     ##  
 ##          #######        ##      #######    #########  
 ##          ##    ##       ##           ##    ##        
 ##    ##    ##     ##      ##     ##    ##    ##        
 ########    ##      ##    ####    ########    ##       
------------------------------------------------------------------------------------------------------------------------------------------------------------------
__author__      = "Mathema VB, Duangkumpha K, Wanichthanarak K, Jariyasopit N, Dhaka E, Sathirapongsasuti N, Kitiyakara C,Sirivatanauksorn Y, Khoomrung S*        |
__institute__   = "Metabolomics and Systems Biology,Department of Biochemistry,Faculty of Medicine Siriraj Hospital, Mahidol University, Bangkok 10700, Thailand" |
__license__     = "GNU/GPL"                                                                                                                                       |
__version__     = "0.01"                                                                                                                                          |
__maintainer__  =  "VBM"                                                                                                                                          |
__email__       = "vivek_mathema@hotmail.com"                                                                                                                     |
__status__      = "Briefings in Bioinformatics (accepted, in press)"                                                                                                                                  |
------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Citation information

@article {vbm2021crisp,
   title ={CRISP: A Deep Learning Architecture for GC×GC-TOFMS Contour ROI Identification, Simulation, and Analysis in Imaging Metabolomics},
   author={Mathema VB, Duangkumpha K, Wanichthanarak K, Jariyasopit N, Dhakal E, Sathirapongsasuti N, Kitiyakara C, Sirivatanauksorn Y, Khoomrung S},
   journal={BIB},
   year={2021}
   }


Part of the article entitled: "CRISP: A Deep Learning Architecture for GC×GC-TOFMS Contour ROI Identification, Simulation, and Analysis in Imaging Metabolomics"

'''

#============================================

import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--gui_type'      , type=int, default= 4                         , help='Use different GUI Schemes [ 0: Breeze, 1: Oxygen, 2: QtCurve, 3: Windows, 4:Fusion ]') #
parser.add_argument('--config_run'    , type=int, default= 0                         , help='[0: false, 1:true]. Run ContourProfiler in GUI mode ONLY. No configuration modules will be run') #self.model_id 
parser.add_argument('--config_fpath'  , type=str, default= './config/default.conf'   , help='full pathname of the configuration file to run') #self.model_id 
parser.add_argument('--run_session'   , type=str, default= None                      
                                      , help=  '[None,gan_train, gan_syn, train_sr, sr_inf, cls_train, cls_inf]\
                                               | None       : Only load gui with selected configuration, \
                                               | gan_train  : Load and run gui for GAN model training, \
                                               | gan_syn    : Load and run gui for GAN synthesis,\
                                               | train_sr   : Load and run gui for contour super resoultion training,\
                                               | sr_inf     : Load and run gui for contour image enhancement,\
                                               | cls_train  : Load and run gui for classifier training,\
                                               | cls_inf    : Load and run gui for classifier inferencing,\
                                               [NOTE: Commandline configuration run is not currently avaiable for ROIs and DeepStacking]' )

     
args = parser.parse_args()

